#include <xdc/std.h>
#ifndef __config__
__FAR__ char ti_sdo_ce_examples_apps_video_copy_dualcpu_separateconfig_dll__dummy__;
#define __xdc_PKGVERS null
#define __xdc_PKGNAME ti.sdo.ce.examples.apps.video_copy.dualcpu_separateconfig_dll
#define __xdc_PKGPREFIX ti_sdo_ce_examples_apps_video_copy_dualcpu_separateconfig_dll_
#ifdef __xdc_bld_pkg_c__
#define __stringify(a) #a
#define __local_include(a) __stringify(a)
#include __local_include(__xdc_bld_pkg_c__)
#endif

#else

#endif
