/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-u12
 */

#ifndef ti_sdo_ce_ipc_dsplink__
#define ti_sdo_ce_ipc_dsplink__



#endif /* ti_sdo_ce_ipc_dsplink__ */ 
